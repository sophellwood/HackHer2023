from flask import Flask, render_template, request, redirect, url_for
app = Flask(__name__)
@app.route("/", methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        if request.form.get('action1') == 'VALUE1':
             return redirect(url_for('home2'))
        elif request.form.get('action2') == 'VALUE2':
            return redirect(url_for('home3'))
        elif request.form.get('action3') == 'VALUE3':
            return redirect(url_for('quiz'))
    
    return(render_template("w3template.html")) 

@app.route("/x", methods=['GET', 'POST'])
def home2():
    if request.method == 'POST':
        if request.form.get('action1') == 'VALUE1':
            return redirect("https://www.crazygames.com/game/cubes-2048-io ")
        elif request.form.get('action2') == 'VALUE2':
            return redirect("https://www.crazygames.com/game/rocket-bot-royale ")
        elif request.form.get('action3') == 'VALUE3':
            return redirect("https://www.crazygames.com/game/smash-karts ")
        elif request.form.get('action4') == 'VALUE4':
            return redirect("https://www.crazygames.com/game/bubble-blast-pwd ")
    return(render_template("w3xPage - calming.html"))

@app.route("/y", methods=['GET', 'POST'])
def home3():
    # return(render_template("test2.html"))
    if request.method == 'POST':
        if request.form.get('action1') == 'VALUE1':
            return redirect("https://www.crazygames.com/game/helix-jump tetris: https://tetris.com/play-tetris  ")
        elif request.form.get('action2') == 'VALUE2':
            return redirect("https://bubblespop.netlify.app/ ")
        elif request.form.get('action3') == 'VALUE3':
            return redirect("https://yandex.com/games/app/172410  ")
        elif request.form.get('action4') == 'VALUE4':
            return redirect("https://2048game.com/ ")
    return(render_template("w3xPage - exciting.html"))


@app.route("/z", methods=['GET', 'POST'])
def quiz():
    # FORM LOGIC to be integrated form python
    hypo = 0
    hyper = 0
    if request.method == 'POST':
        select = request.form['role1']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5
            

                
        select = request.form['role2']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5
            return(str(hypo))

        select = request.form['role3']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5
        
        select = request.form['role4']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5

        select = request.form['role5']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5
 
        select = request.form['role6']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5

        select = request.form['role7']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5

        select = request.form['role8']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5


        select = request.form['role9']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5


        select = request.form['role10']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5

        select = request.form['role11']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5

        select = request.form['role12']
        if select == 'never':
            hypo += 1
        elif select == "rarely":
            hypo += 2
        elif select == "sometimes":
            hypo += 3
        elif select == "often":
            hypo += 4
        elif select == "very often":
            hypo += 5
        if hypo != 0:
            return(str(hypo))
    return(render_template("form_page.html"))


